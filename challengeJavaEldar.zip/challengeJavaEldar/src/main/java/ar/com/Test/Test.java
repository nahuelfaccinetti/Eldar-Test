/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.com.Test;

import ar.com.clases.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 *
 * @author Nahuel
 */
public class Test {
    public static void main(String[] args) throws ParseException{
        CreditCard creditCard1;
        CreditCard creditCard2;
        CreditCard creditCard3;        
        creditCard1 = new CreditCard(BrandsCreditCard.Visa, 13591203, "Juan Perez", "10/07/2021");
        creditCard2 = new CreditCard(BrandsCreditCard.Amex, 23554261, "Esteban Garcia", "30/06/2024");
        creditCard3 = new CreditCard(BrandsCreditCard.Nara, 53437232, "Emilia Gomez", "10/01/2023");
        knowInfo(creditCard1);
        calculateRate(creditCard1.getBrand(), creditCard1.getExpirationDate());
        isValidCard(creditCard1.getExpirationDate());
        isValidOperation(creditCard1.getCreditCardNumber(), 5000);
        knowInfo(creditCard2);
        calculateRate(creditCard2.getBrand(), creditCard2.getExpirationDate());
        isValidCard(creditCard2.getExpirationDate());
        isValidOperation(creditCard2.getCreditCardNumber(), 1000);
        knowInfo(creditCard3);
        calculateRate(creditCard3.getBrand(), creditCard3.getExpirationDate());    
        isValidCard(creditCard3.getExpirationDate());
        isValidOperation(creditCard3.getCreditCardNumber(), 400);
        validateCards(creditCard1.getBrand(), creditCard1.getCreditCardNumber(), creditCard2.getBrand(), creditCard2.getCreditCardNumber());
    }
    
    private static void knowInfo(CreditCard card){
        System.out.println("Tarjeta: " + card.toString());
    }
    
    private static void isValidOperation(int cardNumber, int mount){
        if(mount == 1000 || mount > 1000){
            System.out.println("Operacion invalida para la tarjeta " + cardNumber);
        }else{
            System.out.println("La operacion para la tarjeta " + cardNumber + " es valida");
        }
        System.out.println("\n");
    }
    
    private static void isValidCard(String dateString) throws ParseException{
        LocalDate actualDate = LocalDate.now();
        LocalDate dateCard = LocalDate.parse(dateString, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        if ((actualDate.isEqual(dateCard))||(actualDate.isAfter(dateCard))){
            System.out.println("La tarjeta es Inválida para operar");
        }else{
            System.out.println("La tarjeta es Válida para operar");
        }
    }
    
    private static void calculateRate(String brand, String dateString) throws ParseException{
        double rate = 0;
        try {
            LocalDate date = LocalDate.parse(dateString, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            float year = date.getYear();
            int month = date.getMonthValue();
            int day = date.getDayOfMonth();
            switch (brand) {
                case ("VISA"):
                    rate = (year - 2000) / month;
                    break;
                case ("NARA"):
                    rate = (day * 0.5);
                    break;
                case ("AMEX"):
                    rate = (month * 0.1);
                    break;
                default:
                    System.out.println("No disponemos de ninguna tasa registrada para la marca " + brand);
            }
        } catch (Exception e) {
            System.out.println("Se ha producido un error en la aplicacion");
        }
        System.out.println("Marca de la tarjeta: " + brand + ". Tasa correspondiente: " + rate);
    }

    private static void validateCards(String brand1, int creditCardNumber1, String brand2, int creditCardNumber2) {
        if (brand1.equals(brand2)){
            if(creditCardNumber1 == creditCardNumber2){
                System.out.println("Las tarjetas son iguales");
            }else{
                System.out.println("Tarjetas distintas");
            }
        }else{
            System.out.println("Tarjetas distintas");
        }
    }
}
