package ar.com.clases;

/**
 *
 * @author Nahuel
 */
public final class BrandsCreditCard {
    
    public static final String Visa = "VISA";
    public static final String Nara = "NARA";
    public static final String Amex = "AMEX";
    
}
