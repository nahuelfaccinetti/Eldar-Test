package ar.com.clases;

import java.util.Date;

/**
 *
 * @author Nahuel
 */
public class CreditCard {
    private String brand;
    private int creditCardNumber;
    private String cardHolder;
    private String expirationDate;

    public CreditCard(String brand, int creditCardNumber, String cardHolder, String expirationDate) {
        this.brand = brand;
        this.creditCardNumber = creditCardNumber;
        this.cardHolder = cardHolder;
        this.expirationDate = expirationDate;
    }

    
    
    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getCreditCardNumber() {
        return creditCardNumber;
    }

    public void setCreditCardNumber(int creditCardNumber) {
        this.creditCardNumber = creditCardNumber;
    }

    public String getCardHolder() {
        return cardHolder;
    }

    public void setCardHolder(String cardHolder) {
        this.cardHolder = cardHolder;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    @Override
    public String toString() {
        return "CreditCard{" + "brand=" + brand + ", creditCardNumber=" + creditCardNumber + ", cardHolder=" + cardHolder + ", expirationDate=" + expirationDate + '}';
    }           
}
